var celkovaCena = 0;
var celkomKusy = 0;

function vlozitDoKosika1(){
    var cena = parseFloat(document.getElementById("cena1").innerHTML);
    var kusy = parseFloat(document.getElementById("pocet1").value);

    celkovaCena += (cena*kusy);
    celkomKusy += (kusy);

    document.getElementById("cena").innerHTML = celkovaCena + "€";
    document.getElementById("pocetkosik").innerHTML = celkomKusy + "ks";
}

function vlozitDoKosika2(){
    var cena = parseFloat(document.getElementById("cena2").innerHTML);
    var kusy = parseFloat(document.getElementById("pocet2").value);

    celkovaCena += (cena*kusy);
    celkomKusy += kusy;

    document.getElementById("cena").innerHTML = celkovaCena + "€";
    document.getElementById("pocetkosik").innerHTML = celkomKusy + "ks";
}

function vlozitDoKosika3(){
    var cena = parseFloat(document.getElementById("cena3").innerHTML);
    var kusy = parseFloat(document.getElementById("pocet3").value);

    celkovaCena += (cena*kusy);
    celkomKusy += (kusy);

    document.getElementById("cena").innerHTML = celkovaCena + "€";
    document.getElementById("pocetkosik").innerHTML = celkomKusy + "ks";
}

function mobMenu() {
    document.getElementById("mojemenu").classList.toggle("show");
  }